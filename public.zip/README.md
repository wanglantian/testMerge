# LotterySystem Frontend

Vue 3 + Vite 5 + DevExtreme single-page application for the lottery
drawing system.

## Stack

| Concern         | Choice                                       |
|-----------------|----------------------------------------------|
| Build tool      | Vite 5                                       |
| Framework       | Vue 3 (Composition API, `<script setup>`)    |
| UI components   | DevExtreme Vue (`dxDataGrid`, `dxPopup`, …)  |
| State           | Pinia                                        |
| Routing         | Vue Router 4                                 |
| HTTP            | Axios with interceptors                      |
| Excel export    | DevExtreme `exportDataGrid` + ExcelJS        |
| Styling         | DevExtreme light theme + scoped CSS          |

## Project Layout

```
frontend/
├── index.html
├── package.json
├── vite.config.js
├── public/
│   └── favicon.svg
└── src/
    ├── main.js                 # bootstraps Pinia + Router + DX theme
    ├── App.vue                 # shell with header nav
    ├── router/index.js         # /activities, /draw/:code, /winners/:code
    ├── styles/global.css       # CSS custom properties / resets
    ├── api/
    │   ├── http.js             # axios instance + interceptors
    │   ├── activities.js
    │   ├── prizes.js
    │   ├── lottery.js
    │   └── winners.js
    ├── stores/
    │   ├── activities.js       # Pinia: activity list + current
    │   └── prizes.js           # Pinia: prizes for current celebration
    ├── components/
    │   ├── ActivityStatusBadge.vue
    │   ├── PrizeCard.vue
    │   └── NameRoller.vue      # the rolling animation
    └── views/
        ├── ActivityDashboard.vue
        ├── DrawingPage.vue
        └── WinnersPage.vue
```

## Prerequisites

- Node.js 18+ (Vite 5 requires Node 18 or 20+)
- The .NET backend running on `http://localhost:5180`
  (configurable via `vite.config.js` proxy target)

## Mock-data fallback

The frontend ships with a complete in-browser mock store (`src/api/mockData.js`)
that mirrors the backend's seed data. Each API call is wrapped with
`withMockFallback`: it tries the real backend first and silently falls back to
the mock store on a transport failure. A one-time toast informs the user that
demo mode is active.

You can force a specific mode via Vite env vars:

| Mode      | Set with                                | Behavior                              |
|-----------|-----------------------------------------|---------------------------------------|
| `auto`    | (default) or `VITE_DATA_MODE=auto`      | Try backend, fall back to mock store. |
| `mock`    | `VITE_DATA_MODE=mock`                   | Always use the mock store.            |
| `backend` | `VITE_DATA_MODE=backend`                | Never fall back; surface real errors. |

Example to run the frontend in pure-mock mode (no backend needed):

```bash
# Windows PowerShell
$env:VITE_DATA_MODE="mock"; npm run dev

# bash
VITE_DATA_MODE=mock npm run dev
```

## Run

```bash
cd frontend
npm install
npm run dev
```

The dev server opens at <http://localhost:5173>. All requests to `/api/*` are
proxied to the backend.

## Build for Production

```bash
npm run build
```

Outputs to `dist/`. Serve those static files behind any web server (nginx, IIS,
or the .NET backend's `wwwroot`).

## How the Drawing Flow Works

1. **`ActivityDashboard.vue`** — `dxDataGrid` of activities. Click a row or
   the "Draw" action button to navigate to the drawing page for that
   celebration.
2. **`DrawingPage.vue`** —
   - Loads the celebration, prize list, and eligible-employee pool.
   - Renders prizes as cards via `PrizeCard.vue`, sorted by Priority DESC.
   - When the user clicks **Draw** on a card:
     1. The button disables and a loading state activates.
     2. `lotteryApi.draw(celebrationCode, prizeCode)` POSTs to the backend.
     3. The returned winners are passed to `NameRoller.roll(winners)`.
     4. `NameRoller` cycles random names from the pool for ~3.5s, locks each
        tile to its winner one-by-one over the final 600ms, and emits
        `finished`.
     5. A `dxPopup` reveals the winners with a per-row fade-up animation.
     6. On popup close, prizes + eligible pool refresh so `RemainQty` and
        `Status` reflect the new database state.
3. **`WinnersPage.vue`** — `dxDataGrid` with celebration / time-range filters,
   plus a built-in Excel export button (DevExtreme `exportDataGrid` +
   ExcelJS).

## Design Notes

- **Unified API envelope.** The backend always returns
  `{ success, code, message, data }`. The axios response interceptor unwraps
  `data` for success cases and surfaces a DevExtreme `notify` toast on every
  failure (transport-level or `success === false`).
- **Animation duration.** `NameRoller` is hard-coded to 3500ms (within the
  3-5s spec) with a 70ms tick. Lock staggering across the last 600ms gives the
  reveal a paced feel.
- **Responsive.** Layouts are tested at 1366×768 and 1920×1080. Card grids
  use `auto-fit` / `auto-fill` so they collapse cleanly on narrower screens.
- **Browser storage.** No `localStorage` / `sessionStorage` is used — Pinia
  state is in-memory, refreshed on demand from the backend.

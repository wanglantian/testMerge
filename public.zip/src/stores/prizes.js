import { defineStore } from 'pinia'
import { prizesApi } from '@/api/prizes'

// Store for prizes within a single celebration. Reloads on demand after each
// successful draw so RemainQty / Status reflect the new database state.
export const usePrizesStore = defineStore('prizes', {
  state: () => ({
    /** PrizeDto[] for the active celebration. */
    list: [],
    /** Currently-selected prize on the drawing page. */
    selected: null,
    /** Whether a fetch is in-flight. */
    loading: false
  }),

  getters: {
    /** Prizes that still have remaining quantity to draw. */
    ongoing: (state) => state.list.filter((p) => p.remainQty > 0),

    /** Prize the user clicked on (full DTO from list, not just the code). */
    selectedPrize: (state) =>
      state.selected
        ? state.list.find(
            (p) =>
              p.celebrationCode === state.selected.celebrationCode &&
              p.code === state.selected.code
          ) || state.selected
        : null
  },

  actions: {
    async loadByCelebration(celebrationCode) {
      this.loading = true
      try {
        const data = await prizesApi.getByCelebration(celebrationCode)
        this.list = Array.isArray(data) ? data : []
      } finally {
        this.loading = false
      }
    },

    select(prize) {
      this.selected = prize
    },

    clearSelection() {
      this.selected = null
    }
  }
})

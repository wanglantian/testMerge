import { defineStore } from 'pinia'
import { activitiesApi } from '@/api/activities'

// Minimal store that caches the activity list and the currently-selected one.
// Pages call loadAll() / loadActive() and bind directly to the reactive state.
export const useActivitiesStore = defineStore('activities', {
  state: () => ({
    /** All activities (ActivityDto[]). */
    list: [],
    /** Currently-selected activity for the drawing / winners pages. */
    current: null,
    /** Whether the most recent fetch is in-flight. */
    loading: false,
    /** ISO timestamp of the last successful load. */
    lastLoadedAt: null
  }),

  getters: {
    /** Activities considered "Active" by the backend. */
    activeOnly: (state) => state.list.filter((a) => a.status === 2)
  },

  actions: {
    async loadAll() {
      this.loading = true
      try {
        const data = await activitiesApi.getAll()
        this.list = Array.isArray(data) ? data : []
        this.lastLoadedAt = new Date().toISOString()
      } finally {
        this.loading = false
      }
    },

    async loadActive() {
      const data = await activitiesApi.getActive()
      this.current = data || null
      return this.current
    },

    async loadByCode(code) {
      const data = await activitiesApi.getByCode(code)
      this.current = data || null
      return this.current
    },

    /** Set current without a network call - useful when a list row is clicked. */
    selectCurrent(activity) {
      this.current = activity
    }
  }
})

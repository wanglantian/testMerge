<script setup>
import { computed } from 'vue'

// Small chip that maps an ActivityStatus enum value to a colored label.
// Used in the activity dashboard grid and the drawing page header.

const props = defineProps({
  /** ActivityStatus value: 0=Disabled, 1=Upcoming, 2=Active, 3=Ended. */
  status: {
    type: Number,
    required: true
  }
})

const meta = computed(() => {
  switch (props.status) {
    case 0:
      return { label: 'Disabled', cls: 'badge-disabled' }
    case 1:
      return { label: 'Upcoming', cls: 'badge-upcoming' }
    case 2:
      return { label: 'Active', cls: 'badge-active' }
    case 3:
      return { label: 'Ended', cls: 'badge-ended' }
    default:
      return { label: 'Unknown', cls: 'badge-disabled' }
  }
})
</script>

<template>
  <span class="status-badge" :class="meta.cls">
    <span class="status-dot"></span>
    {{ meta.label }}
  </span>
</template>

<style scoped>
.status-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 3px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  white-space: nowrap;
}

.status-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
}

.badge-active {
  color: #2e7d32;
  background: #e8f5e9;
}

.badge-upcoming {
  color: #1565c0;
  background: #e3f2fd;
}

.badge-ended {
  color: #6a1b9a;
  background: #f3e5f5;
}

.badge-disabled {
  color: #616161;
  background: #f5f5f5;
}
</style>

<script setup>
import { ref, computed, watch, onBeforeUnmount } from 'vue'

// NameRoller renders a grid of slot tiles whose count matches the currently
// selected prize. When idle, every slot shows a dimmed "?" placeholder - no
// employee info is leaked before the draw starts. When the spin starts, slots
// fill with random pool names cycling rapidly. When the spin ends, the slots
// snap to the actual winner names (bright + crown badge); any slots beyond
// the winner count just freeze on whatever pool entry was visible.
//
// Driving inputs (props):
//   - pool          : EmployeeDto[]  (eligible employees)
//   - slotCount     : number         (== current prize's RemainQty, capped)
//   - duration      : number ms      (spin length when stopMode === 'auto')
//   - stopMode      : 'auto' | 'manual'
//
// External controls (defineExpose):
//   - start()       : begin spinning (no winners yet)
//   - reveal(winners) : snap slots to winners and emit 'finished'
//   - cancel()      : stop everything immediately
//   - reset()       : clear all tiles back to idle
//
// Two-click flow (stopMode='manual'):
//   parent calls start() on first Draw click, calls reveal(winners) on second.
//
// One-click flow (stopMode='auto'):
//   parent calls start() then immediately reveal(winners); the roller spins
//   for `duration` then locks. The reveal call queues the winners.

const props = defineProps({
  /** Eligible employee pool used to seed the rolling names. */
  pool: {
    type: Array,
    default: () => []
  },
  /**
   * How many slot tiles to render. Should equal the selected prize's
   * RemainQty (capped to a sane max for layout). 0 = no slots visible.
   */
  slotCount: {
    type: Number,
    default: 0
  },
  /** Spin duration when stopMode === 'auto'. Should be 3000-5000. */
  duration: {
    type: Number,
    default: 3500
  },
  /** Tick interval - how often the displayed name changes. */
  tickInterval: {
    type: Number,
    default: 70
  },
  /**
   * Stop policy:
   *  - 'auto'   : reveal() can be called immediately; spin runs for `duration`,
   *               then locks to the queued winners.
   *  - 'manual' : the spin keeps going until reveal() is called; on call,
   *               slots lock to the supplied winners after a short tail.
   */
  stopMode: {
    type: String,
    default: 'manual'
  }
})

const emit = defineEmits(['finished'])

// Per-slot state.
const tiles = ref([])
const phase = ref('idle')        // 'idle' | 'spinning' | 'revealed'
let tickHandle = null
let tailHandle = null

// Pool draw helper.
function randomEmp() {
  if (!props.pool.length) return null
  return props.pool[Math.floor(Math.random() * props.pool.length)]
}

// Build N empty placeholder tiles. The placeholder text is deliberately a
// single "?" so no employee identity is exposed before the draw.
function buildIdleTiles(count) {
  return Array.from({ length: count }, () => ({
    currentName: '?',
    currentCard: '',
    currentDept: '',
    finalName: '',
    finalCard: '',
    finalDept: '',
    isWinner: false,
    locked: false,
    placeholder: true
  }))
}

// Whenever the prize selection changes we rebuild idle tiles so the slot count
// matches. We do NOT do this while spinning - that would visibly snap mid-roll.
watch(
  () => props.slotCount,
  (next) => {
    if (phase.value === 'spinning') return
    tiles.value = buildIdleTiles(next || 0)
    phase.value = 'idle'
  },
  { immediate: true }
)

/** Begin the rolling animation. Slots fill with rotating pool names. */
function start() {
  cancel()

  const n = props.slotCount || 0
  if (n <= 0) return

  // Seed each slot with a random pool entry so the user immediately sees motion.
  tiles.value = Array.from({ length: n }, () => {
    const seed = randomEmp()
    return {
      currentName: seed?.name || '?',
      currentCard: seed?.cardNumber || '',
      currentDept: seed?.department || '',
      finalName: '',
      finalCard: '',
      finalDept: '',
      isWinner: false,
      locked: false,
      placeholder: false
    }
  })
  phase.value = 'spinning'

  tickHandle = window.setInterval(() => {
    for (const t of tiles.value) {
      if (!t.locked) {
        const emp = randomEmp()
        if (emp) {
          t.currentName = emp.name
          t.currentCard = emp.cardNumber
          t.currentDept = emp.department || ''
        }
      }
    }
  }, props.tickInterval)
}

/**
 * Lock slots to the supplied winners and end the animation.
 * - In 'manual' mode, takes effect ~700ms later (a graceful tail).
 * - In 'auto' mode, schedules the lock so total spin time === props.duration.
 *
 * Safe to call before start() in 'auto' mode - we'll start automatically.
 */
function reveal(winners) {
  if (!Array.isArray(winners)) winners = []

  if (phase.value === 'idle' && props.stopMode === 'auto') {
    start()
  }

  if (phase.value !== 'spinning') {
    // No spin in progress; just emit so the caller's flow doesn't stall.
    emit('finished', winners)
    return
  }

  const tail = props.stopMode === 'auto'
    ? Math.max(props.duration, 1000)
    : 700                                      // manual mode: short, snappy tail

  // Pre-bind which slots will hold the winners. We pick from the front so
  // they read top-left to bottom-right naturally.
  const tilesArr = tiles.value
  for (let i = 0; i < winners.length && i < tilesArr.length; i++) {
    tilesArr[i].finalName = winners[i].employeeName
    tilesArr[i].finalCard = winners[i].employeeCardNumber
    tilesArr[i].finalDept = winners[i].department || ''
    tilesArr[i].isWinner = true
  }

  // Schedule lock-staggering. Winners snap one-by-one over the last 600ms,
  // then non-winner slots all lock together at the very end.
  const winnerLockStart = Math.max(0, tail - 600)
  const lockSpacing = winners.length > 0
    ? Math.max(60, Math.floor(550 / winners.length))
    : 0

  for (let i = 0; i < winners.length && i < tilesArr.length; i++) {
    window.setTimeout(() => {
      const t = tiles.value[i]
      if (!t) return
      t.currentName = t.finalName
      t.currentCard = t.finalCard
      t.currentDept = t.finalDept
      t.locked = true
    }, winnerLockStart + i * lockSpacing)
  }

  tailHandle = window.setTimeout(() => {
    for (const t of tiles.value) {
      if (!t.isWinner) t.locked = true
    }
    if (tickHandle) {
      window.clearInterval(tickHandle)
      tickHandle = null
    }
    phase.value = 'revealed'
    emit('finished', winners)
  }, tail)
}

/** Stop everything immediately, clear timers, leave tiles as-is. */
function cancel() {
  if (tickHandle) {
    window.clearInterval(tickHandle)
    tickHandle = null
  }
  if (tailHandle) {
    window.clearTimeout(tailHandle)
    tailHandle = null
  }
  if (phase.value === 'spinning') {
    phase.value = 'idle'
  }
}

/** Reset all slots to the idle placeholder state. */
function reset() {
  cancel()
  tiles.value = buildIdleTiles(props.slotCount || 0)
  phase.value = 'idle'
}

onBeforeUnmount(() => {
  cancel()
})

const isSpinning = computed(() => phase.value === 'spinning')
const showPlaceholderText = computed(() => tiles.value.length === 0)

defineExpose({ start, reveal, cancel, reset })
</script>

<template>
  <div class="name-roller" :class="{ rolling: isSpinning }">
    <div v-if="showPlaceholderText" class="empty-state">
      <span class="empty-glyph">🎰</span>
      <span class="empty-text">Select a prize to set up the lottery slots.</span>
    </div>

    <div v-else class="tiles-grid">
      <div
        v-for="(tile, idx) in tiles"
        :key="idx"
        class="tile"
        :class="{
          'tile-placeholder': tile.placeholder,
          'tile-spinning': isSpinning && !tile.locked,
          'tile-winner': tile.isWinner && tile.locked,
          'tile-not-winner': !tile.isWinner && tile.locked
        }"
      >
        <div class="tile-name">{{ tile.currentName }}</div>
        <div v-if="!tile.placeholder" class="tile-meta">
          <span v-if="tile.currentCard" class="tile-card">{{ tile.currentCard }}</span>
          <span v-if="tile.currentDept" class="tile-dept">{{ tile.currentDept }}</span>
        </div>
        <div v-if="tile.isWinner && tile.locked" class="winner-crown">👑</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.name-roller {
  width: 100%;
  min-height: 280px;
  padding: 16px;
  border-radius: var(--radius-lg);
  background: linear-gradient(135deg, #fff8e1 0%, #ffe0b2 100%);
  border: 2px dashed #ffb74d;
  position: relative;
  overflow: hidden;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  color: #8d6e63;
  min-height: 220px;
}

.empty-glyph {
  font-size: 56px;
}

.empty-text {
  font-size: 14px;
  text-align: center;
}

.tiles-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 8px;
  width: 100%;
}

.tile {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 70px;
  padding: 8px 10px;
  border-radius: var(--radius-sm);
  background: #fff;
  box-shadow: var(--shadow-sm);
  position: relative;
  overflow: hidden;
  transition: transform 0.25s ease, box-shadow 0.25s ease,
              opacity 0.4s ease, background 0.3s ease;
}

/* Idle placeholder slot - just a "?" with no employee context. */
.tile.tile-placeholder {
  background: rgba(255, 255, 255, 0.55);
  border: 1px dashed rgba(141, 110, 99, 0.4);
  box-shadow: none;
}

.tile.tile-placeholder .tile-name {
  font-size: 22px;
  color: rgba(141, 110, 99, 0.55);
}

/* Spinning tile - subtle vertical jitter on the name. */
.tile.tile-spinning .tile-name {
  animation: nameSpin 0.18s linear infinite;
}

@keyframes nameSpin {
  0% { transform: translateY(4px); opacity: 0.5; }
  50% { transform: translateY(0); opacity: 1; }
  100% { transform: translateY(-4px); opacity: 0.5; }
}

/* Winner tile - bright gold + crown + scale pulse. */
.tile.tile-winner {
  background: linear-gradient(135deg, #fff176 0%, #ffb300 100%);
  box-shadow: 0 6px 18px rgba(255, 152, 0, 0.5);
  transform: scale(1.06);
  z-index: 2;
  animation: pulseLock 0.6s ease;
}

@keyframes pulseLock {
  0% { transform: scale(0.92); }
  60% { transform: scale(1.12); }
  100% { transform: scale(1.06); }
}

/* Non-winner tile after lock - faded so winners stand out. */
.tile.tile-not-winner {
  opacity: 0.4;
  filter: saturate(0.5);
}

.tile-name {
  font-size: 15px;
  font-weight: 700;
  color: var(--primary-dark);
  letter-spacing: 0.3px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100%;
  text-align: center;
}

.tile.tile-winner .tile-name {
  color: #d84315;
  font-size: 16px;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
}

.tile-meta {
  margin-top: 4px;
  display: flex;
  gap: 4px;
  font-size: 10px;
  color: var(--text-secondary);
  flex-wrap: wrap;
  justify-content: center;
  max-width: 100%;
}

.tile-card {
  font-family: "JetBrains Mono", "Consolas", monospace;
  background: rgba(0, 0, 0, 0.06);
  padding: 1px 5px;
  border-radius: 3px;
  white-space: nowrap;
}

.tile-dept {
  color: #5d4037;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100%;
}

.winner-crown {
  position: absolute;
  top: -2px;
  right: 4px;
  font-size: 16px;
  filter: drop-shadow(0 1px 2px rgba(0, 0, 0, 0.2));
}

@media (max-width: 1440px) {
  .tiles-grid {
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: 6px;
  }
  .tile {
    min-height: 60px;
    padding: 6px 8px;
  }
  .tile-name {
    font-size: 13px;
  }
  .tile.tile-winner .tile-name {
    font-size: 14px;
  }
  .tile.tile-placeholder .tile-name {
    font-size: 20px;
  }
}
</style>

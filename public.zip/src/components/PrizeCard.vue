<script setup>
import { computed } from 'vue'

// Single prize card on the drawing page. Shows image, name, draw progress,
// remaining count and the Draw button. Emits 'draw' when clicked; the parent
// handles the API call and animation.

const props = defineProps({
  /** PrizeDto. */
  prize: {
    type: Object,
    required: true
  },
  /** True while a draw is in-flight for this card. */
  drawing: {
    type: Boolean,
    default: false
  },
  /** True when the parent has selected this card. */
  selected: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['draw', 'select'])

// The button is disabled when there's nothing to draw or a draw is already
// happening. We expose a computed so the template stays simple.
const isDone = computed(() => props.prize.remainQty <= 0 || props.prize.status === 1)
const canDraw = computed(() => !isDone.value && !props.drawing)

// Number of complete draw rounds based on Quantity / NumberOfRound.
const totalRounds = computed(() => {
  const round = Math.max(1, props.prize.numberOfRound || 1)
  return Math.ceil(props.prize.quantity / round)
})

const completedRounds = computed(() => {
  const round = Math.max(1, props.prize.numberOfRound || 1)
  return Math.floor(props.prize.winnedQuantity / round)
})

// imagePath is stored as a full URL. Use it as-is; trim whitespace defensively.
// Empty / null values yield an empty string and the template falls back to the
// 🎁 placeholder glyph.
const imageUrl = computed(() => {
  const path = props.prize.imagePath
  return typeof path === 'string' ? path.trim() : ''
})

function handleDraw() {
  if (!canDraw.value) return
  emit('draw', props.prize)
}

function handleSelect() {
  emit('select', props.prize)
}
</script>

<template>
  <div
    class="prize-card"
    :class="{
      done: isDone,
      drawing,
      selected
    }"
    @click="handleSelect"
  >
    <div class="image-wrap">
      <img
        v-if="imageUrl"
        class="prize-image"
        :src="imageUrl"
        :alt="prize.name"
        @error="(e) => (e.target.style.display = 'none')"
      />
      <div v-else class="prize-image-placeholder">🎁</div>
      <div v-if="isDone" class="done-badge">DONE</div>
      <div v-else class="priority-badge">P{{ prize.priority }}</div>
    </div>

    <div class="prize-body">
      <div class="prize-name">{{ prize.name }}</div>
      <div class="prize-desc" :title="prize.description">
        {{ prize.description || '—' }}
      </div>

      <div class="prize-stats">
        <div class="stat">
          <span class="stat-label">Remaining</span>
          <span class="stat-value remain">{{ prize.remainQty }} / {{ prize.quantity }}</span>
        </div>
        <div class="stat">
          <span class="stat-label">Per round</span>
          <span class="stat-value">{{ prize.numberOfRound }}</span>
        </div>
        <div class="stat">
          <span class="stat-label">Round</span>
          <span class="stat-value">{{ completedRounds }} / {{ totalRounds }}</span>
        </div>
      </div>

      <button
        class="draw-button"
        :disabled="isDone"
        @click.stop="handleDraw"
      >
        <span v-if="isDone">Completed</span>
        <span v-else-if="selected">Selected ✓</span>
        <span v-else>Select</span>
      </button>
    </div>
  </div>
</template>

<style scoped>
.prize-card {
  display: flex;
  flex-direction: column;
  background: var(--bg-card);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
  border: 2px solid transparent;
  cursor: pointer;
  transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
  overflow: hidden;
}

.prize-card:hover:not(.done) {
  transform: translateY(-3px);
  box-shadow: var(--shadow-md);
  border-color: rgba(233, 30, 99, 0.3);
}

.prize-card.selected {
  border-color: var(--primary);
  box-shadow: 0 6px 20px rgba(233, 30, 99, 0.25);
}

.prize-card.done {
  opacity: 0.65;
  cursor: not-allowed;
}

.image-wrap {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 10;
  background: linear-gradient(135deg, #f8bbd0 0%, #fce4ec 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.prize-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.prize-image-placeholder {
  font-size: 64px;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.15));
}

.done-badge,
.priority-badge {
  position: absolute;
  top: 10px;
  right: 10px;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.6px;
  color: #fff;
}

.priority-badge {
  background: rgba(0, 0, 0, 0.55);
  backdrop-filter: blur(4px);
}

.done-badge {
  background: #757575;
}

.prize-body {
  padding: 14px 16px 16px;
  display: flex;
  flex-direction: column;
  flex: 1;
  gap: 10px;
}

.prize-name {
  font-size: 17px;
  font-weight: 700;
  color: var(--text-primary);
}

.prize-desc {
  font-size: 12px;
  color: var(--text-secondary);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  min-height: 32px;
}

.prize-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 6px;
  padding: 8px;
  background: var(--bg-page);
  border-radius: var(--radius-sm);
}

.stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
}

.stat-label {
  font-size: 10px;
  color: var(--text-secondary);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.stat-value {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary);
}

.stat-value.remain {
  color: var(--primary);
}

.draw-button {
  margin-top: auto;
  padding: 10px 16px;
  border: none;
  border-radius: var(--radius-sm);
  background: linear-gradient(90deg, var(--primary) 0%, #ff5722 100%);
  color: #fff;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease, opacity 0.15s ease;
}

.draw-button:hover:not(:disabled) {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(233, 30, 99, 0.35);
}

.draw-button:active:not(:disabled) {
  transform: translateY(0);
}

.draw-button:disabled {
  background: #bdbdbd;
  cursor: not-allowed;
  opacity: 0.85;
}
</style>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { storeToRefs } from 'pinia'

import DxButton from 'devextreme-vue/button'
import DxLoadPanel from 'devextreme-vue/load-panel'
import DxPopup from 'devextreme-vue/popup'

import NameRoller from '@/components/NameRoller.vue'
import ActivityStatusBadge from '@/components/ActivityStatusBadge.vue'

import { lotteryApi } from '@/api/lottery'
import { useActivitiesStore } from '@/stores/activities'
import { usePrizesStore } from '@/stores/prizes'

// ---------------------------------------------------------------------------
// Drawing page (revised layout)
//
// Layout
//   ┌─────────────────────────────┬───────────────────────────────────┐
//   │  Prize cards (left column)  │  Name roller (right, top)         │
//   │  scrollable, ordered by     │  Slot count = selected prize's    │
//   │  Priority desc              │  RemainQty (or NumberOfRound)     │
//   │                             │                                   │
//   │  Click a card to select it  │  Big "Draw" button below roller   │
//   │  (highlight only)           │  Two-click flow:                  │
//   │                             │   1st click  → start spinning     │
//   │                             │   2nd click  → POST /draw, lock   │
//   └─────────────────────────────┴───────────────────────────────────┘
//
// Workflow
//   1. Page mounts → fetch celebration, prizes, eligible employees.
//   2. Auto-select the first ongoing prize.
//   3. Roller renders empty placeholder slots whose count == prize.RemainQty
//      (capped at MAX_SLOTS so layout doesn't explode).
//   4. User clicks "Draw" → roller.start() and the button becomes "Stop".
//   5. User clicks "Stop" → POST /Lottery/draw → roller.reveal(winners).
//   6. roller emits 'finished' once the lock animation completes → popup opens.
//   7. Popup close → refresh prizes + eligible pool.
// ---------------------------------------------------------------------------

const MAX_SLOTS = 60                     // Hard cap so a 1000-qty prize doesn't melt the layout.

const route = useRoute()
const router = useRouter()

const activitiesStore = useActivitiesStore()
const prizesStore = usePrizesStore()

const { current: activity } = storeToRefs(activitiesStore)
const { list: prizes, loading: prizesLoading } = storeToRefs(prizesStore)

// Local state.
const eligiblePool = ref([])
const lastResult = ref(null)
const popupVisible = ref(false)
const rollerRef = ref(null)

// Spin state machine: 'idle' → 'spinning' → 'revealing' → 'idle'
const spinState = ref('idle')

// Prize ordering (Priority DESC, then code).
const sortedPrizes = computed(() => {
  const arr = [...(prizes.value || [])]
  arr.sort((a, b) => {
    if (b.priority !== a.priority) return b.priority - a.priority
    return (a.code || '').localeCompare(b.code || '')
  })
  return arr
})

const eligibleCount = computed(() => eligiblePool.value.length)
const ongoingCount = computed(() => sortedPrizes.value.filter((p) => p.remainQty > 0).length)

// Current prize = the first ongoing prize in priority order. Auto-advances
// whenever the latest prize list arrives (e.g. after a successful draw): if
// the previous current prize's RemainQty just hit zero, the .find() naturally
// skips it and returns the next one. No user selection is involved.
const currentPrize = computed(
  () => sortedPrizes.value.find((p) => p.remainQty > 0) || null
)

// Prizes still ongoing AFTER the current one - shown as the "Up next" queue.
const upcomingPrizes = computed(() => {
  const cur = currentPrize.value
  if (!cur) return []
  return sortedPrizes.value.filter(
    (p) => p.remainQty > 0 && !(p.code === cur.code && p.celebrationCode === cur.celebrationCode)
  )
})

// Prizes that are fully drawn - shown as collapsed pills at the bottom.
const completedPrizes = computed(
  () => sortedPrizes.value.filter((p) => p.remainQty <= 0)
)

// 0..100 progress fill for the current prize bar.
const currentProgressPct = computed(() => {
  const p = currentPrize.value
  if (!p || !p.quantity) return 0
  return Math.round((p.winnedQuantity / p.quantity) * 100)
})

// imagePath is stored as a full URL (per backend convention) - use it as-is.
// We only trim whitespace defensively so a stray space in the data doesn't
// break the <img src>. Empty / null values yield an empty string and the
// template falls back to the placeholder glyph.
const currentPrizeImageUrl = computed(() => {
  const path = currentPrize.value?.imagePath
  return typeof path === 'string' ? path.trim() : ''
})

// The prize whose draw produced lastResult. We look it up against the prize
// list rather than reusing currentPrize because by the time the popup is
// visible, currentPrize may have already advanced to the next ongoing prize
// (when the just-drawn one's RemainQty hit zero).
const lastDrawnPrize = computed(() => {
  const code = lastResult.value?.prizeCode
  if (!code) return null
  return sortedPrizes.value.find((p) => p.code === code) || null
})

const lastDrawnPrizeImageUrl = computed(() => {
  const path = lastDrawnPrize.value?.imagePath
  return typeof path === 'string' ? path.trim() : ''
})

// Slot count for the roller = how many entries are drawn in the current round.
// That's `numberOfRound`, but capped at `remainQty` so the final round of a
// prize doesn't render more slots than there are prizes left to award. Also
// capped at MAX_SLOTS so the layout stays sane.
const slotCount = computed(() => {
  const p = currentPrize.value
  if (!p) return 0
  const perRound = Math.max(1, p.numberOfRound || 1)
  const capped = Math.min(perRound, p.remainQty)
  return Math.min(MAX_SLOTS, Math.max(0, capped))
})

const drawButtonState = computed(() => {
  if (!currentPrize.value) {
    return { label: 'All prizes drawn', disabled: true, variant: 'secondary' }
  }
  if (currentPrize.value.remainQty <= 0) {
    return { label: 'Prize completed', disabled: true, variant: 'secondary' }
  }
  if (eligibleCount.value === 0) {
    return { label: 'No eligible employees', disabled: true, variant: 'secondary' }
  }
  if (activity.value?.status !== 2) {
    return { label: 'Celebration not active', disabled: true, variant: 'secondary' }
  }
  if (spinState.value === 'idle') {
    return { label: 'Start Drawing', disabled: false, variant: 'primary' }
  }
  if (spinState.value === 'spinning') {
    return { label: 'Stop & Reveal', disabled: false, variant: 'danger' }
  }
  // 'revealing' - in flight; button must be disabled to prevent re-clicks.
  return { label: 'Revealing…', disabled: true, variant: 'secondary' }
})

// ---- Data loading ----

async function ensureCelebration() {
  const code = route.params.celebrationCode
  if (code) {
    if (!activity.value || activity.value.code !== code) {
      await activitiesStore.loadByCode(code)
    }
    return
  }

  await activitiesStore.loadActive()
  if (activity.value?.code) {
    router.replace({ name: 'draw', params: { celebrationCode: activity.value.code } })
  }
}

async function loadPrizes() {
  if (!activity.value?.code) return
  await prizesStore.loadByCelebration(activity.value.code)
}

async function loadEligible() {
  if (!activity.value?.code) {
    eligiblePool.value = []
    return
  }
  try {
    const data = await lotteryApi.getEligible(activity.value.code)
    eligiblePool.value = Array.isArray(data) ? data : []
  } catch {
    eligiblePool.value = []
  }
}

// ---- Button interaction ----

// Single button toggles between Start and Stop. The roller stays in 'spinning'
// state until the API call returns and the reveal completes.
async function onDrawClick() {
  if (drawButtonState.value.disabled) return

  if (spinState.value === 'idle') {
    // Phase 1: kick off the spin. No API call yet.
    spinState.value = 'spinning'
    rollerRef.value?.start()
    return
  }

  if (spinState.value === 'spinning') {
    // Phase 2: API call + reveal. We move to 'revealing' to lock out repeat clicks.
    spinState.value = 'revealing'

    try {
      const target = currentPrize.value
      if (!target) {
        rollerRef.value?.cancel()
        rollerRef.value?.reset()
        spinState.value = 'idle'
        return
      }

      const result = await lotteryApi.draw(target.celebrationCode, target.code)

      if (!result?.winners?.length) {
        // Edge case: no winners returned. Stop the roller and reset.
        rollerRef.value?.cancel()
        rollerRef.value?.reset()
        spinState.value = 'idle'
        return
      }

      lastResult.value = result
      rollerRef.value?.reveal(result.winners)
    } catch {
      // Toast already shown by the axios interceptor.
      rollerRef.value?.cancel()
      rollerRef.value?.reset()
      spinState.value = 'idle'
    }
  }
}

// Roller finished its lock animation → reveal the popup.
function onRollFinished() {
  setTimeout(() => {
    popupVisible.value = true
  }, 0)
}

function closePopup() {
  popupVisible.value = false
}

async function onPopupHidden() {
  popupVisible.value = false
  spinState.value = 'idle'

  // Refresh underlying data so the prize card and pool reflect the new state.
  try {
    await Promise.all([loadPrizes(), loadEligible()])
  } catch {
    /* already toasted */
  }

  // Reset the roller so it goes back to placeholder slots. The currentPrize
  // computed will automatically advance to the next ongoing prize on the next
  // tick because RemainQty for the just-drawn prize has decreased.
  rollerRef.value?.reset()
}

function backToActivities() {
  router.push({ name: 'activities' })
}

function openWinnersPage() {
  if (!activity.value?.code) return
  router.push({ name: 'winners', params: { celebrationCode: activity.value.code } })
}

// ---- Lifecycle ----

onMounted(async () => {
  await ensureCelebration()
  await Promise.all([loadPrizes(), loadEligible()])
})

watch(
  () => route.params.celebrationCode,
  async (newCode, oldCode) => {
    if (newCode && newCode !== oldCode) {
      await ensureCelebration()
      await Promise.all([loadPrizes(), loadEligible()])
    }
  }
)
</script>

<template>
  <div class="page draw-page">
    <!-- Header -->
    <div class="page-header">
      <div class="header-left">
        <DxButton icon="back" styling-mode="text" @click="backToActivities" />
        <div>
          <h2 class="page-title">
            {{ activity?.name || 'Drawing' }}
            <ActivityStatusBadge v-if="activity" :status="activity.status" class="header-badge" />
          </h2>
          <p class="page-subtitle">
            <span v-if="activity">Code: <strong>{{ activity.code }}</strong></span>
            <span v-else>Loading celebration…</span>
            <span class="dot">•</span>
            Eligible pool: <strong>{{ eligibleCount }}</strong>
            <span class="dot">•</span>
            Ongoing prizes: <strong>{{ ongoingCount }}</strong>
          </p>
        </div>
      </div>
      <div class="header-right">
        <DxButton
          icon="trophy"
          text="View Winners"
          styling-mode="outlined"
          @click="openWinnersPage"
        />
      </div>
    </div>

    <!-- Banner states -->
    <div v-if="activity && activity.status !== 2" class="banner banner-warning">
      <span class="banner-icon">⚠</span>
      <span>This celebration is not currently active. Drawing is disabled.</span>
    </div>
    <div v-else-if="activity && eligibleCount === 0" class="banner banner-info">
      <span class="banner-icon">ℹ</span>
      <span>All employees have already won at least once. The eligible pool is empty.</span>
    </div>

    <!-- Two-column layout: prizes left, lottery area right -->
    <div class="draw-layout">
      <!-- LEFT: single current prize, with a small queue underneath -->
      <section class="prizes-column">
        <h3 class="section-title">Current Prize</h3>

        <div v-if="sortedPrizes.length === 0 && !prizesLoading" class="empty">
          <span class="empty-icon">🎁</span>
          <span>No prizes are configured for this celebration.</span>
        </div>

        <div v-else-if="!currentPrize" class="empty">
          <span class="empty-icon">🏁</span>
          <span>All prizes have been fully drawn.</span>
        </div>

        <template v-else>
          <!--
            One prominent card for the prize being drawn right now. Selection
            is no longer user-driven - the system advances automatically once
            the current prize's RemainQty hits zero (see onPopupHidden).
          -->
          <div class="current-prize-card">
            <div class="current-image-wrap">
              <img
                v-if="currentPrizeImageUrl"
                class="current-image"
                :src="currentPrizeImageUrl"
                :alt="currentPrize.name"
                @error="(e) => (e.target.style.display = 'none')"
              />
              <div v-else class="current-image-placeholder">🎁</div>
            </div>
            <div class="current-body">
              <div class="current-name">{{ currentPrize.name }}</div>
              <div class="current-desc">{{ currentPrize.description || '—' }}</div>
              <div class="current-progress">
                <div class="current-progress-bar">
                  <div
                    class="current-progress-fill"
                    :style="{ width: `${currentProgressPct}%` }"
                  ></div>
                </div>
                <div class="current-progress-stats">
                  <span><strong>{{ currentPrize.winnedQuantity }}</strong> awarded</span>
                  <span><strong>{{ currentPrize.remainQty }}</strong> remaining</span>
                  <span><strong>{{ currentPrize.numberOfRound }}</strong> per round</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Queue of upcoming prizes, ordered by priority desc. -->
          <div v-if="upcomingPrizes.length > 0" class="upcoming-list">
            <div class="upcoming-title">Up next</div>
            <ol class="upcoming-items">
              <li
                v-for="p in upcomingPrizes"
                :key="p.code"
                class="upcoming-item"
              >
                <span class="upcoming-name">{{ p.name }}</span>
                <span class="upcoming-remain">×{{ p.remainQty }}</span>
              </li>
            </ol>
          </div>

          <!-- Done prizes - collapsed list at the bottom. -->
          <div v-if="completedPrizes.length > 0" class="completed-list">
            <div class="completed-title">Completed ({{ completedPrizes.length }})</div>
            <div class="completed-items">
              <span
                v-for="p in completedPrizes"
                :key="p.code"
                class="completed-pill"
              >
                {{ p.name }}
              </span>
            </div>
          </div>
        </template>
      </section>

      <!-- RIGHT: lottery area -->
      <section class="lottery-column">
        <h3 class="section-title">Lottery</h3>

        <!-- Round summary so user knows what's about to be drawn. -->
        <div v-if="currentPrize" class="selected-prize">
          <div class="selected-name">Drawing: {{ currentPrize.name }}</div>
          <div v-if="currentPrize.description" class="selected-desc">
            {{ currentPrize.description }}
          </div>
          <div class="selected-stats">
            <span class="stat-chip">Remaining <strong>{{ currentPrize.remainQty }}</strong></span>
            <span class="stat-chip">Per round <strong>{{ currentPrize.numberOfRound }}</strong></span>
            <span class="stat-chip">This round <strong>{{ slotCount }}</strong></span>
          </div>
        </div>
        <div v-else class="selected-prize selected-prize-empty">
          All prizes have been fully drawn.
        </div>

        <!-- Roller with N placeholder slots (where N = slotCount). -->
        <NameRoller
          ref="rollerRef"
          :pool="eligiblePool"
          :slot-count="slotCount"
          stop-mode="manual"
          @finished="onRollFinished"
        />

        <!-- Big draw button below the roller. -->
        <button
          class="big-draw-button"
          :class="`btn-${drawButtonState.variant}`"
          :disabled="drawButtonState.disabled"
          @click="onDrawClick"
        >
          <span class="btn-text">{{ drawButtonState.label }}</span>
        </button>

        <p class="hint">
          {{
            spinState === 'idle'
              ? 'Click "Start Drawing" to begin the spin.'
              : spinState === 'spinning'
                ? 'Click "Stop & Reveal" when ready to lock the winners.'
                : 'Locking winners…'
          }}
        </p>
      </section>
    </div>

    <!-- Winner reveal popup -->
    <!--
      Notes on the blank-area fix:
       * No :title on the popup. We render the heading inside the content slot
         so DX doesn't reserve unexpected vertical space for a title bar.
       * No :height='auto' nor wrapping DxScrollView. DX sizes the popup to its
         content, with the popup's own scrolling enabled.
       * v-model:visible keeps DX and Vue in sync; @hidden runs after close.
    -->
    <DxPopup
      v-model:visible="popupVisible"
      :show-title="false"
      :drag-enabled="false"
      :hide-on-outside-click="true"
      :show-close-button="false"
      :width="1100"
      :max-width="'95vw'"
      :height="'auto'"
      :max-height="'90vh'"
      :wrapper-attr="{ class: 'lottery-winner-popup' }"
      @hidden="onPopupHidden"
    >
      <template #content>
        <div v-if="lastResult" class="popup-body">
          <header class="popup-header">
            <div v-if="lastDrawnPrizeImageUrl" class="popup-prize-thumb">
              <img
                :src="lastDrawnPrizeImageUrl"
                :alt="lastResult.prizeName"
                @error="(e) => (e.target.style.display = 'none')"
              />
            </div>
            <div v-else class="popup-prize-thumb popup-prize-thumb-empty">🎁</div>
            <div class="popup-header-text">
              <div class="popup-title">{{ lastResult.prizeName }}</div>
              <div
                v-if="lastDrawnPrize?.description"
                class="popup-description"
              >
                {{ lastDrawnPrize.description }}
              </div>
              <div class="popup-subtitle">Winners</div>
            </div>
          </header>

          <div class="popup-summary">
            <div class="summary-pill">
              <span class="pill-label">Round</span>
              <span class="pill-value">#{{ lastResult.roundNumber }}</span>
            </div>
            <div class="summary-pill">
              <span class="pill-label">Picked</span>
              <span class="pill-value">{{ lastResult.winnersPicked }}</span>
            </div>
            <div class="summary-pill">
              <span class="pill-label">Remaining</span>
              <span class="pill-value">{{ lastResult.remainQty }}</span>
            </div>
          </div>

          <!--
            Winner grid: square tiles laid out in a responsive auto-fit grid.
            Each tile is fixed at ~160px so a 12-winner reveal fits in two
            rows on a 1100px popup, and a 24-winner reveal fits in four rows
            on a 1080p screen without scrolling. Above that, DX falls back to
            internal scroll - acceptable for the rare big-batch case.
          -->
          <div class="winner-grid" :class="`winner-grid-count-${lastResult.winners.length}`">
            <div
              v-for="(w, idx) in lastResult.winners"
              :key="w.employeeCardNumber"
              class="winner-tile"
              :style="{ animationDelay: `${Math.min(idx, 12) * 0.05}s` }"
            >
              <div class="winner-tile-name" :title="w.employeeName">
                {{ w.employeeName }}
              </div>
              <div class="winner-tile-card">{{ w.employeeCardNumber }}</div>
              <div v-if="w.department" class="winner-tile-dept" :title="w.department">
                {{ w.department }}
              </div>
            </div>
          </div>

          <div class="popup-actions">
            <DxButton
              text="Close"
              type="default"
              styling-mode="contained"
              @click="closePopup"
            />
          </div>
        </div>
        <div v-else class="popup-body popup-body-empty">
          <span>No winners to display.</span>
        </div>
      </template>
    </DxPopup>

    <!-- Loading overlay during initial fetch -->
    <DxLoadPanel
      :visible="prizesLoading && sortedPrizes.length === 0"
      :show-indicator="true"
      :show-pane="true"
      :shading="true"
      message="Loading prizes…"
    />
  </div>
</template>

<style scoped>
.draw-page {
  min-height: 100%;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-badge {
  margin-left: 8px;
  vertical-align: middle;
}

.page-subtitle .dot {
  margin: 0 6px;
  color: var(--border);
}

/* --- Two-column layout --- */
.draw-layout {
  display: grid;
  grid-template-columns: minmax(280px, 1fr) minmax(0, 1.6fr);
  gap: 18px;
  align-items: stretch;
}

@media (max-width: 1100px) {
  .draw-layout {
    grid-template-columns: 1fr;
  }
}

.prizes-column,
.lottery-column {
  background: var(--bg-card);
  border-radius: var(--radius-md);
  padding: 16px 18px;
  box-shadow: var(--shadow-sm);
  display: flex;
  flex-direction: column;
  min-height: 480px;
}

.prizes-column {
  /* Allow the prize grid to scroll independently if it overflows. */
  max-height: calc(100vh - 220px);
  overflow-y: auto;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
  margin: 0 0 12px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.section-title::before {
  content: '';
  display: inline-block;
  width: 4px;
  height: 16px;
  background: var(--primary);
  border-radius: 2px;
}

/* --- Current prize card (left column) --- */
.current-prize-card {
  display: flex;
  flex-direction: column;
  background: var(--bg-card);
  border-radius: var(--radius-md);
  border: 2px solid var(--primary);
  box-shadow: 0 6px 18px rgba(233, 30, 99, 0.18);
  overflow: hidden;
  margin-bottom: 16px;
}

.current-image-wrap {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 9;
  background: linear-gradient(135deg, #f8bbd0 0%, #fce4ec 100%);
  display: flex;
  align-items: center;
  justify-content: center;
}

.current-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.current-image-placeholder {
  font-size: 96px;
  filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.18));
}

.current-body {
  padding: 16px 18px 18px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.current-name {
  font-size: 22px;
  font-weight: 800;
  color: var(--primary-dark);
}

.current-desc {
  font-size: 13px;
  color: var(--text-secondary);
  line-height: 1.45;
}

.current-progress {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 4px;
}

.current-progress-bar {
  width: 100%;
  height: 8px;
  background: var(--bg-page);
  border-radius: 999px;
  overflow: hidden;
}

.current-progress-fill {
  height: 100%;
  background: linear-gradient(90deg, var(--primary) 0%, #ff5722 100%);
  border-radius: 999px;
  transition: width 0.4s ease;
}

.current-progress-stats {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: var(--text-secondary);
  flex-wrap: wrap;
  gap: 8px;
}

.current-progress-stats strong {
  color: var(--primary);
}

/* --- Up next queue --- */
.upcoming-list {
  margin-bottom: 12px;
}

.upcoming-title {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  color: var(--text-secondary);
  margin-bottom: 6px;
}

.upcoming-items {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.upcoming-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  background: var(--bg-page);
  border-radius: var(--radius-sm);
  font-size: 13px;
}

.upcoming-name {
  flex: 1;
  color: var(--text-primary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.upcoming-remain {
  font-size: 12px;
  color: var(--text-secondary);
  font-family: "JetBrains Mono", "Consolas", monospace;
}

/* --- Completed pills --- */
.completed-list {
  margin-top: auto;
  padding-top: 10px;
  border-top: 1px dashed var(--border);
}

.completed-title {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  color: var(--text-secondary);
  margin-bottom: 6px;
}

.completed-items {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.completed-pill {
  font-size: 11px;
  color: var(--text-secondary);
  background: var(--bg-page);
  padding: 2px 8px;
  border-radius: 999px;
  text-decoration: line-through;
  opacity: 0.7;
}

/* --- Lottery column: roller + button + hint --- */
.selected-prize {
  background: linear-gradient(90deg, #fff8e1 0%, #ffe0b2 100%);
  border-radius: var(--radius-sm);
  padding: 12px 14px;
  margin-bottom: 12px;
  border-left: 4px solid #ff8a00;
}

.selected-prize-empty {
  background: #f5f5f5;
  border-left-color: var(--border);
  color: var(--text-secondary);
  font-style: italic;
}

.selected-name {
  font-size: 16px;
  font-weight: 700;
  color: #bf360c;
  margin-bottom: 6px;
}

.selected-desc {
  font-size: 13px;
  color: #5d4037;
  line-height: 1.45;
  margin-bottom: 8px;
  /* Cap at three lines so a verbose description doesn't push the roller down. */
  display: -webkit-box;
  -webkit-line-clamp: 3;
  line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.selected-stats {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.stat-chip {
  background: rgba(255, 255, 255, 0.6);
  border-radius: 999px;
  padding: 3px 10px;
  font-size: 12px;
  color: #5d4037;
}

.stat-chip strong {
  color: #bf360c;
  margin-left: 4px;
}

/* The big draw button below the roller. */
.big-draw-button {
  margin-top: 16px;
  padding: 16px 24px;
  border: none;
  border-radius: var(--radius-md);
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 0.5px;
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease, opacity 0.15s ease;
  width: 100%;
}

.big-draw-button:hover:not(:disabled) {
  transform: translateY(-2px);
}

.big-draw-button:disabled {
  cursor: not-allowed;
  opacity: 0.7;
}

.btn-primary {
  background: linear-gradient(90deg, var(--primary) 0%, #ff5722 100%);
  color: #fff;
  box-shadow: 0 4px 12px rgba(233, 30, 99, 0.3);
}

.btn-primary:hover:not(:disabled) {
  box-shadow: 0 6px 18px rgba(233, 30, 99, 0.45);
}

.btn-danger {
  background: linear-gradient(90deg, #d32f2f 0%, #ff6f00 100%);
  color: #fff;
  box-shadow: 0 4px 12px rgba(211, 47, 47, 0.35);
  animation: btnPulse 1.4s ease-in-out infinite;
}

@keyframes btnPulse {
  0%, 100% { box-shadow: 0 4px 12px rgba(211, 47, 47, 0.35); }
  50% { box-shadow: 0 6px 22px rgba(211, 47, 47, 0.55); }
}

.btn-secondary {
  background: #bdbdbd;
  color: #fff;
}

.hint {
  margin: 8px 0 0;
  text-align: center;
  font-size: 12px;
  color: var(--text-secondary);
}

/* --- Banners --- */
.banner {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  border-radius: var(--radius-sm);
  margin-bottom: 16px;
  font-size: 14px;
}

.banner-warning {
  background: #fff3e0;
  color: #e65100;
  border-left: 4px solid #fb8c00;
}

.banner-info {
  background: #e3f2fd;
  color: #1565c0;
  border-left: 4px solid #1976d2;
}

.banner-icon {
  font-size: 18px;
}

.empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 60px 20px;
  color: var(--text-secondary);
  border: 2px dashed var(--border);
  border-radius: var(--radius-md);
}

.empty-icon {
  font-size: 48px;
}
</style>

<!--
  Non-scoped popup styles. DevExtreme teleports the popup wrapper to
  document.body, which can put it outside the reach of <style scoped>. We
  re-apply the rules under .lottery-winner-popup so they're isolated to this
  page's popup but still take effect after teleport.
-->
<style>
.lottery-winner-popup .dx-popup-content {
  /* Reset DX padding so our header sits at the very top of the dialog. */
  padding: 0 !important;
}

.lottery-winner-popup .popup-body {
  padding: 18px 22px 18px;
  display: flex;
  flex-direction: column;
  gap: 14px;
  min-height: 100px;
}

.lottery-winner-popup .popup-body-empty {
  align-items: center;
  justify-content: center;
  color: #616161;
  font-size: 14px;
  padding: 32px 16px;
}

.lottery-winner-popup .popup-header {
  display: flex;
  align-items: center;
  gap: 14px;
  border-bottom: 1px solid #ffe082;
  padding-bottom: 12px;
  margin-bottom: 4px;
}

.lottery-winner-popup .popup-prize-thumb {
  flex-shrink: 0;
  width: 72px;
  height: 72px;
  border-radius: 8px;
  overflow: hidden;
  background: linear-gradient(135deg, #f8bbd0 0%, #fce4ec 100%);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.12);
  display: flex;
  align-items: center;
  justify-content: center;
}

.lottery-winner-popup .popup-prize-thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.lottery-winner-popup .popup-prize-thumb-empty {
  font-size: 36px;
}

.lottery-winner-popup .popup-header-text {
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.lottery-winner-popup .popup-title {
  font-size: 18px;
  font-weight: 700;
  color: #bf360c;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.lottery-winner-popup .popup-description {
  font-size: 13px;
  color: #5d4037;
  line-height: 1.4;
  margin-top: 4px;
  /* Cap at two lines so a verbose description doesn't push winners off the
     visible area. The full text is in the title attr / left column already. */
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.lottery-winner-popup .popup-subtitle {
  font-size: 12px;
  color: #6d4c41;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-top: 6px;
}

.lottery-winner-popup .popup-actions {
  display: flex;
  justify-content: flex-end;
  padding-top: 8px;
  border-top: 1px solid #e0e0e0;
}

.lottery-winner-popup .popup-summary {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.lottery-winner-popup .summary-pill {
  background: linear-gradient(135deg, #ffe0b2 0%, #ffcc80 100%);
  border-radius: 999px;
  padding: 6px 14px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.lottery-winner-popup .pill-label {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #6d4c41;
}

.lottery-winner-popup .pill-value {
  font-size: 16px;
  font-weight: 700;
  color: #bf360c;
}

/* ---- Winner tile grid ---- */

.lottery-winner-popup .winner-grid {
  display: grid;
  /* auto-fit with 160px minimum gives:
       1100px wide popup → up to 6 columns
       760px wide popup  → 4 columns
       380px wide popup  → 2 columns
  */
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 12px;
  /* Cap at 6 columns on very wide displays so tiles don't get tiny. */
  max-width: 100%;
}

/*
  When there are very few winners, force a more comfortable max column
  count so the tiles don't stretch into giant flat rectangles.
*/
.lottery-winner-popup .winner-grid-count-1,
.lottery-winner-popup .winner-grid-count-2,
.lottery-winner-popup .winner-grid-count-3,
.lottery-winner-popup .winner-grid-count-4 {
  grid-template-columns: repeat(auto-fit, minmax(180px, 200px));
  justify-content: center;
}

.lottery-winner-popup .winner-tile {
  /* Square. min-height matches the column min so tiles render as squares
     even when grid stretches them slightly to fill the row. */
  aspect-ratio: 1 / 1;
  min-height: 160px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  gap: 8px;
  padding: 16px 12px;
  background: linear-gradient(135deg, #fffde7 0%, #ffe082 100%);
  border-radius: 12px;
  border: 1px solid #ffd54f;
  box-shadow: 0 4px 12px rgba(255, 152, 0, 0.18);
  position: relative;
  overflow: hidden;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  animation: lotteryTilePop 0.45s cubic-bezier(0.34, 1.56, 0.64, 1) backwards;
}

.lottery-winner-popup .winner-tile:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(255, 152, 0, 0.32);
}

@keyframes lotteryTilePop {
  0% {
    opacity: 0;
    transform: scale(0.6);
  }
  60% {
    opacity: 1;
    transform: scale(1.06);
  }
  100% {
    opacity: 1;
    transform: scale(1);
  }
}

.lottery-winner-popup .winner-tile-name {
  font-size: 18px;
  font-weight: 800;
  color: #bf360c;
  letter-spacing: 0.3px;
  width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  padding: 0 4px;
}

.lottery-winner-popup .winner-tile-card {
  font-family: "JetBrains Mono", "Consolas", monospace;
  font-size: 11px;
  color: #5d4037;
  background: rgba(255, 255, 255, 0.7);
  padding: 2px 8px;
  border-radius: 999px;
  white-space: nowrap;
}

.lottery-winner-popup .winner-tile-dept {
  font-size: 11px;
  color: #6d4c41;
  width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  padding: 0 4px;
}

@media (max-width: 1100px) {
  .lottery-winner-popup .winner-grid {
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 10px;
  }
  .lottery-winner-popup .winner-tile {
    min-height: 140px;
    padding: 10px 8px;
  }
  .lottery-winner-popup .winner-tile-name {
    font-size: 14px;
  }
}
</style>

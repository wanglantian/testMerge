<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { storeToRefs } from 'pinia'

import DxDataGrid, {
  DxColumn,
  DxFilterRow,
  DxHeaderFilter,
  DxPaging,
  DxScrolling,
  DxSearchPanel,
  DxSelection,
  DxToolbar,
  DxItem
} from 'devextreme-vue/data-grid'
import DxButton from 'devextreme-vue/button'
import DxLoadPanel from 'devextreme-vue/load-panel'

import ActivityStatusBadge from '@/components/ActivityStatusBadge.vue'
import { useActivitiesStore } from '@/stores/activities'

// The dashboard is the entry page. It lists every celebration as a dxDataGrid
// row and offers card-style summary tiles at the top. Clicking a row routes to
// the drawing page for that celebration.

const router = useRouter()
const store = useActivitiesStore()
const { list, loading } = storeToRefs(store)

// Filter state for the toolbar - we deliberately offer 'All' + each enum value.
// 0=Disabled, 1=Upcoming, 2=Active, 3=Ended.
const statusFilter = ref('all')

const filteredList = computed(() => {
  if (statusFilter.value === 'all') return list.value
  const target = Number(statusFilter.value)
  return list.value.filter((a) => a.status === target)
})

// Quick stats shown above the grid.
const stats = computed(() => {
  const all = list.value || []
  return {
    total: all.length,
    active: all.filter((a) => a.status === 2).length,
    upcoming: all.filter((a) => a.status === 1).length,
    ended: all.filter((a) => a.status === 3).length
  }
})

const statusOptions = [
  { value: 'all', label: 'All' },
  { value: 2, label: 'Active' },
  { value: 1, label: 'Upcoming' },
  { value: 3, label: 'Ended' },
  { value: 0, label: 'Disabled' }
]

function setFilter(value) {
  statusFilter.value = value
}

// Row selection -> drawing page. We pre-select the activity in the store so the
// drawing page can render immediately without an extra fetch.
function openDraw(activity) {
  if (!activity) return
  store.selectCurrent(activity)
  router.push({ name: 'draw', params: { celebrationCode: activity.code } })
}

function openWinners(activity) {
  if (!activity) return
  store.selectCurrent(activity)
  router.push({ name: 'winners', params: { celebrationCode: activity.code } })
}

function onRowClick(e) {
  // Ignore clicks on the action-cell buttons - they handle their own navigation.
  if (e?.event?.target?.closest('.action-button')) return
  openDraw(e.data)
}

function onRefresh() {
  store.loadAll()
}

// dxDataGrid uses status as a numeric column; provide a calc field so the
// header filter and search panel surface human-readable labels.
function statusText(status) {
  const opt = statusOptions.find((o) => o.value === status)
  return opt ? opt.label : 'Unknown'
}

function formatDate(value) {
  if (!value) return ''
  const d = new Date(value)
  if (Number.isNaN(d.getTime())) return value
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

onMounted(() => {
  store.loadAll()
})
</script>

<template>
  <div class="page">
    <div class="page-header">
      <div>
        <h2 class="page-title">Activity Dashboard</h2>
        <p class="page-subtitle">Browse all lottery celebrations and pick one to draw.</p>
      </div>
      <DxButton
        icon="refresh"
        text="Refresh"
        type="default"
        styling-mode="contained"
        @click="onRefresh"
      />
    </div>

    <!-- Summary tiles -->
    <div class="stat-tiles">
      <div class="tile tile-total" :class="{ active: statusFilter === 'all' }" @click="setFilter('all')">
        <span class="tile-label">Total</span>
        <span class="tile-value">{{ stats.total }}</span>
      </div>
      <div class="tile tile-active" :class="{ active: statusFilter === 2 }" @click="setFilter(2)">
        <span class="tile-label">Active</span>
        <span class="tile-value">{{ stats.active }}</span>
      </div>
      <div class="tile tile-upcoming" :class="{ active: statusFilter === 1 }" @click="setFilter(1)">
        <span class="tile-label">Upcoming</span>
        <span class="tile-value">{{ stats.upcoming }}</span>
      </div>
      <div class="tile tile-ended" :class="{ active: statusFilter === 3 }" @click="setFilter(3)">
        <span class="tile-label">Ended</span>
        <span class="tile-value">{{ stats.ended }}</span>
      </div>
    </div>

    <!-- Activities grid -->
    <div class="grid-shell">
      <DxDataGrid
        :data-source="filteredList"
        :show-borders="false"
        :show-row-lines="true"
        :show-column-lines="false"
        :hover-state-enabled="true"
        :row-alternation-enabled="false"
        :column-auto-width="true"
        key-expr="code"
        @row-click="onRowClick"
      >
        <DxToolbar>
          <DxItem location="before">
            <template #default>
              <span class="grid-toolbar-title">{{ filteredList.length }} activities</span>
            </template>
          </DxItem>
          <DxItem name="searchPanel" location="after" />
        </DxToolbar>

        <DxSearchPanel :visible="true" :width="240" placeholder="Search..." />
        <DxFilterRow :visible="true" />
        <DxHeaderFilter :visible="true" />
        <DxScrolling mode="standard" />
        <DxPaging :page-size="20" />
        <DxSelection mode="single" />

        <DxColumn data-field="code" caption="Code" :width="120" />
        <DxColumn data-field="name" caption="Name" :min-width="220" />
        <DxColumn
          data-field="startTime"
          caption="Start"
          :width="170"
          data-type="datetime"
          :customize-text="(c) => formatDate(c.value)"
        />
        <DxColumn
          data-field="endTime"
          caption="End"
          :width="170"
          data-type="datetime"
          :customize-text="(c) => formatDate(c.value)"
        />
        <DxColumn
          data-field="status"
          caption="Status"
          :width="120"
          alignment="center"
          :calculate-cell-value="(row) => statusText(row.status)"
          cell-template="statusCell"
        />
        <DxColumn data-field="prizeCount" caption="Prizes" :width="100" alignment="center" />
        <DxColumn data-field="winnerCount" caption="Winners" :width="100" alignment="center" />
        <DxColumn
          caption="Actions"
          :width="200"
          alignment="center"
          cell-template="actionsCell"
          :allow-filtering="false"
          :allow-sorting="false"
        />

        <template #statusCell="{ data }">
          <ActivityStatusBadge :status="data.data.status" />
        </template>

        <template #actionsCell="{ data }">
          <div class="action-buttons">
            <button
              class="action-button primary"
              :disabled="data.data.status !== 2"
              @click.stop="openDraw(data.data)"
            >
              Draw
            </button>
            <button class="action-button secondary" @click.stop="openWinners(data.data)">
              Winners
            </button>
          </div>
        </template>
      </DxDataGrid>

      <DxLoadPanel
        :visible="loading"
        :show-indicator="true"
        :show-pane="true"
        :shading="true"
        message="Loading activities..."
      />
    </div>
  </div>
</template>

<style scoped>
.stat-tiles {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 14px;
  margin-bottom: 18px;
}

.tile {
  background: var(--bg-card);
  border-radius: var(--radius-md);
  padding: 16px 18px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  cursor: pointer;
  border: 2px solid transparent;
  box-shadow: var(--shadow-sm);
  transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease;
}

.tile:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-md);
}

.tile.active {
  border-color: var(--primary);
}

.tile-label {
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--text-secondary);
}

.tile-value {
  font-size: 28px;
  font-weight: 700;
  color: var(--text-primary);
}

.tile-total .tile-value { color: #424242; }
.tile-active .tile-value { color: #2e7d32; }
.tile-upcoming .tile-value { color: #1565c0; }
.tile-ended .tile-value { color: #6a1b9a; }

.grid-shell {
  position: relative;
  background: var(--bg-card);
  border-radius: var(--radius-md);
  padding: 8px;
  box-shadow: var(--shadow-sm);
}

.grid-toolbar-title {
  font-size: 13px;
  color: var(--text-secondary);
  padding: 0 8px;
}

.action-buttons {
  display: inline-flex;
  gap: 6px;
}

.action-button {
  padding: 5px 12px;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: opacity 0.15s ease, transform 0.15s ease;
}

.action-button:hover:not(:disabled) {
  transform: translateY(-1px);
}

.action-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.action-button.primary {
  background: var(--primary);
  color: #fff;
}

.action-button.secondary {
  background: #eceff1;
  color: var(--text-primary);
}
</style>

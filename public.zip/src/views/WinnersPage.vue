<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

import DxDataGrid, {
  DxColumn,
  DxColumnChooser,
  DxExport,
  DxFilterRow,
  DxGroupPanel,
  DxGrouping,
  DxHeaderFilter,
  DxPaging,
  DxScrolling,
  DxSearchPanel,
  DxToolbar,
  DxItem
} from 'devextreme-vue/data-grid'
import DxButton from 'devextreme-vue/button'
import DxLoadPanel from 'devextreme-vue/load-panel'
import DxSelectBox from 'devextreme-vue/select-box'
import DxDateBox from 'devextreme-vue/date-box'

import { winnersApi } from '@/api/winners'
import { activitiesApi } from '@/api/activities'

import { exportDataGrid } from 'devextreme/excel_exporter'
import { Workbook } from 'exceljs'
import { saveAs } from 'file-saver-es'

// The Winners page is a single big dxDataGrid. Filters are bound to a small
// toolbar above the grid. Exporting hands off to DevExtreme's built-in
// exportDataGrid helper (per the spec: "front-end export by devextreme").

const route = useRoute()
const router = useRouter()

// ---- Filter state ----
const celebrations = ref([])
const celebrationCode = ref(null)
const beginTime = ref(getDefaultBegin())
const endTime = ref(getDefaultEnd())

const winners = ref([])
const loading = ref(false)
const gridRef = ref(null)

function getDefaultBegin() {
  const d = new Date()
  d.setDate(d.getDate() - 7)
  d.setHours(0, 0, 0, 0)
  return d
}

function getDefaultEnd() {
  const d = new Date()
  d.setDate(d.getDate() + 1)
  d.setHours(23, 59, 59, 0)
  return d
}

// Build the celebration dropdown items: a dummy "All" plus every code/name pair.
const celebrationOptions = computed(() => {
  const items = celebrations.value.map((c) => ({
    code: c.code,
    name: `${c.code} · ${c.name}`
  }))
  return [{ code: null, name: 'All celebrations' }, ...items]
})

async function loadCelebrations() {
  try {
    const data = await activitiesApi.getAll()
    celebrations.value = Array.isArray(data) ? data : []
  } catch {
    celebrations.value = []
  }
}

async function loadWinners() {
  loading.value = true
  try {
    const params = {}
    if (celebrationCode.value) params.celebrationCode = celebrationCode.value
    if (beginTime.value) params.beginTime = toIsoLocal(beginTime.value)
    if (endTime.value) params.endTime = toIsoLocal(endTime.value)

    const data = await winnersApi.query(params)
    winners.value = Array.isArray(data) ? data : []
  } catch {
    winners.value = []
  } finally {
    loading.value = false
  }
}

// Use a local-time ISO format the backend can parse without timezone weirdness.
function toIsoLocal(date) {
  if (!(date instanceof Date)) return date
  const pad = (n) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
}

function resetFilters() {
  celebrationCode.value = null
  beginTime.value = getDefaultBegin()
  endTime.value = getDefaultEnd()
  loadWinners()
}

function backToActivities() {
  router.push({ name: 'activities' })
}

// DevExtreme export hook. We follow the documented exceljs + file-saver-es
// recipe so the user gets a real .xlsx file with formatted columns.
function onExporting(e) {
  if (e.format !== 'xlsx') return

  const workbook = new Workbook()
  const worksheet = workbook.addWorksheet('Winners')

  exportDataGrid({
    component: e.component,
    worksheet,
    autoFilterEnabled: true
  }).then(() => {
    workbook.xlsx.writeBuffer().then((buffer) => {
      const stamp = new Date()
      const pad = (n) => String(n).padStart(2, '0')
      const filename = `winners_${stamp.getFullYear()}${pad(stamp.getMonth() + 1)}${pad(stamp.getDate())}_${pad(stamp.getHours())}${pad(stamp.getMinutes())}${pad(stamp.getSeconds())}.xlsx`

      saveAs(
        new Blob([buffer], { type: 'application/octet-stream' }),
        filename
      )
    })
  })

  e.cancel = true
}

function formatDate(value) {
  if (!value) return ''
  const d = new Date(value)
  if (Number.isNaN(d.getTime())) return value
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
}

// Initial load. Pre-populate the celebration filter from the route param so a
// deep link from the dashboard / drawing page lands on a focused view.
onMounted(async () => {
  if (route.params.celebrationCode) {
    celebrationCode.value = route.params.celebrationCode
  }
  await loadCelebrations()
  await loadWinners()
})

// Keep the URL in sync when the user changes the filter so deep links remain
// shareable, but don't trigger another fetch from the navigation.
watch(celebrationCode, (val) => {
  if (val) {
    router.replace({ name: 'winners', params: { celebrationCode: val } }).catch(() => {})
  } else {
    router.replace({ name: 'winners', params: {} }).catch(() => {})
  }
})
</script>

<template>
  <div class="page">
    <div class="page-header">
      <div class="header-left">
        <DxButton icon="back" styling-mode="text" @click="backToActivities" />
        <div>
          <h2 class="page-title">Winners</h2>
          <p class="page-subtitle">Filter, browse, and export winner records.</p>
        </div>
      </div>
    </div>

    <!-- Filter bar -->
    <div class="filter-bar">
      <div class="filter-item">
        <label class="filter-label">Celebration</label>
        <DxSelectBox
          v-model:value="celebrationCode"
          :data-source="celebrationOptions"
          display-expr="name"
          value-expr="code"
          placeholder="All celebrations"
          :search-enabled="true"
          :show-clear-button="true"
          width="280"
        />
      </div>
      <div class="filter-item">
        <label class="filter-label">From</label>
        <DxDateBox
          v-model:value="beginTime"
          type="datetime"
          display-format="yyyy-MM-dd HH:mm"
          width="200"
        />
      </div>
      <div class="filter-item">
        <label class="filter-label">To</label>
        <DxDateBox
          v-model:value="endTime"
          type="datetime"
          display-format="yyyy-MM-dd HH:mm"
          width="200"
        />
      </div>
      <div class="filter-actions">
        <DxButton icon="search" text="Search" type="default" @click="loadWinners" />
        <DxButton icon="revert" text="Reset" styling-mode="outlined" @click="resetFilters" />
      </div>
    </div>

    <!-- Grid -->
    <div class="grid-shell">
      <DxDataGrid
        ref="gridRef"
        :data-source="winners"
        :show-borders="false"
        :show-row-lines="true"
        :show-column-lines="false"
        :hover-state-enabled="true"
        :column-auto-width="true"
        :allow-column-resizing="true"
        :allow-column-reordering="true"
        key-expr="interID"
        @exporting="onExporting"
      >
        <DxToolbar>
          <DxItem location="before">
            <template #default>
              <span class="grid-toolbar-title">{{ winners.length }} winners</span>
            </template>
          </DxItem>
          <DxItem name="groupPanel" location="before" />
          <DxItem name="exportButton" location="after" />
          <DxItem name="columnChooserButton" location="after" />
          <DxItem name="searchPanel" location="after" />
        </DxToolbar>

        <DxSearchPanel :visible="true" :width="240" placeholder="Search..." />
        <DxFilterRow :visible="true" />
        <DxHeaderFilter :visible="true" />
        <DxGroupPanel :visible="true" empty-panel-text="Drag a column header here to group" />
        <DxGrouping :auto-expand-all="true" />
        <DxColumnChooser :enabled="true" mode="select" />
        <DxScrolling mode="standard" />
        <DxPaging :page-size="50" />
        <DxExport :enabled="true" :formats="['xlsx']" :allow-export-selected-data="false" />

        <DxColumn data-field="employeeCardNumber" caption="Card Number" :width="130" />
        <DxColumn data-field="employeeName" caption="Employee Name" :min-width="140" />
        <DxColumn data-field="department" caption="Department" :min-width="160" />
        <DxColumn data-field="celebrationCode" caption="Celebration Code" :width="160" />
        <DxColumn data-field="celebrationName" caption="Celebration" :min-width="180" />
        <DxColumn data-field="prizeCode" caption="Prize Code" :width="120" />
        <DxColumn data-field="prizeName" caption="Prize" :min-width="200" />
        <DxColumn data-field="quantity" caption="Qty" :width="80" alignment="center" />
        <DxColumn
          data-field="winTime"
          caption="Win Time"
          :width="170"
          data-type="datetime"
          :customize-text="(c) => formatDate(c.value)"
        />
        <DxColumn
          data-field="absentFlag"
          caption="Absent"
          :width="90"
          alignment="center"
          data-type="boolean"
        />
        <DxColumn
          data-field="createdTime"
          caption="Created"
          :width="170"
          data-type="datetime"
          :customize-text="(c) => formatDate(c.value)"
          :visible="false"
        />
      </DxDataGrid>

      <DxLoadPanel
        :visible="loading"
        :show-indicator="true"
        :show-pane="true"
        :shading="true"
        message="Loading winners..."
      />
    </div>
  </div>
</template>

<style scoped>
.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.filter-bar {
  background: var(--bg-card);
  border-radius: var(--radius-md);
  padding: 14px 16px;
  display: flex;
  align-items: flex-end;
  gap: 14px;
  flex-wrap: wrap;
  margin-bottom: 16px;
  box-shadow: var(--shadow-sm);
}

.filter-item {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.filter-label {
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--text-secondary);
  font-weight: 600;
}

.filter-actions {
  display: flex;
  gap: 8px;
  align-items: center;
  margin-left: auto;
}

.grid-shell {
  position: relative;
  background: var(--bg-card);
  border-radius: var(--radius-md);
  padding: 8px;
  box-shadow: var(--shadow-sm);
}

.grid-toolbar-title {
  font-size: 13px;
  color: var(--text-secondary);
  padding: 0 8px;
}
</style>

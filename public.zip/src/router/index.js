import { createRouter, createWebHistory } from 'vue-router'

// Page-level route definitions. Lazy-imported so each view ships in its own chunk.
const routes = [
  {
    path: '/',
    redirect: { name: 'activities' }
  },
  {
    path: '/activities',
    name: 'activities',
    component: () => import('@/views/ActivityDashboard.vue'),
    meta: { title: 'Activities' }
  },
  {
    path: '/draw/:celebrationCode?',
    name: 'draw',
    component: () => import('@/views/DrawingPage.vue'),
    props: true,
    meta: { title: 'Drawing' }
  },
  {
    path: '/winners/:celebrationCode?',
    name: 'winners',
    component: () => import('@/views/WinnersPage.vue'),
    props: true,
    meta: { title: 'Winners' }
  },
  {
    // Catch-all so a stray URL doesn't break the shell.
    path: '/:pathMatch(.*)*',
    redirect: { name: 'activities' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.afterEach((to) => {
  if (to.meta?.title) {
    document.title = `${to.meta.title} · Lottery System`
  }
})

export default router

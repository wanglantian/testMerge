<script setup>
import { computed } from 'vue'
import { useRoute, RouterLink, RouterView } from 'vue-router'

const route = useRoute()
const currentName = computed(() => route.name || '')

// Fixed navigation entries. Wired with RouterLink so the URL bar reflects state
// and deep links are shareable.
const navItems = [
  { name: 'activities', label: 'Activities', icon: '📋' },
  { name: 'draw', label: 'Drawing', icon: '🎲' },
  { name: 'winners', label: 'Winners', icon: '🏆' }
]
</script>

<template>
  <div class="app-shell">
    <header class="app-header">
      <div class="brand">
        <span class="brand-mark">🎉</span>
        <span class="brand-name">Lottery System</span>
      </div>
      <nav class="nav">
        <RouterLink
          v-for="item in navItems"
          :key="item.name"
          :to="{ name: item.name }"
          class="nav-link"
          :class="{ active: currentName === item.name }"
        >
          <span class="nav-icon">{{ item.icon }}</span>
          <span class="nav-text">{{ item.label }}</span>
        </RouterLink>
      </nav>
    </header>
    <main class="app-body">
      <RouterView />
    </main>
  </div>
</template>

<style scoped>
.app-shell {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 56px;
  padding: 0 20px;
  background: linear-gradient(90deg, #e91e63 0%, #ff5722 100%);
  color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  position: sticky;
  top: 0;
  z-index: 100;
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
  font-size: 18px;
}

.brand-mark {
  font-size: 22px;
}

.nav {
  display: flex;
  gap: 4px;
}

.nav-link {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 14px;
  border-radius: var(--radius-sm);
  color: rgba(255, 255, 255, 0.85);
  font-weight: 500;
  font-size: 14px;
  transition: all 0.2s ease;
}

.nav-link:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
  text-decoration: none;
}

.nav-link.active {
  background: rgba(255, 255, 255, 0.22);
  color: #fff;
}

.app-body {
  flex: 1;
  overflow-y: auto;
}
</style>

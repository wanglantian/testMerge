import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'

// DevExtreme global stylesheets. Light theme is fine for our needs; switch to
// dx.dark.css for a dark-themed shell.
import 'devextreme/dist/css/dx.light.css'

import './styles/global.css'

const app = createApp(App)

app.use(createPinia())
app.use(router)

app.mount('#app')

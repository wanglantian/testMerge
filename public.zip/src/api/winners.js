import http, { withMockFallback } from './http'
import { mockApi } from './mockData'

// Wrapper around /api/Winners.
export const winnersApi = {
  query(params = {}) {
    return withMockFallback(
      () => http.get('/Winners', { params }),
      () => mockApi.queryWinners(params)
    )
  },

  updateAbsent(payload) {
    return withMockFallback(
      () => http.post('/Winners/absent', payload),
      () => mockApi.updateAbsent(payload)
    )
  },

  delete(celebrationCode, employeeCardNumber) {
    return withMockFallback(
      () => http.delete(
        `/Winners/${encodeURIComponent(celebrationCode)}/${encodeURIComponent(employeeCardNumber)}`
      ),
      () => mockApi.deleteWinner(celebrationCode, employeeCardNumber)
    )
  }
}

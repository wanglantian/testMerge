// Frontend-side mock data, used as a fallback when the backend isn't reachable
// (e.g. you're demoing on a machine without the .NET runtime). The shape and
// values mirror the backend's MockDataSeeder so the UI looks identical whether
// the data comes from the API or from this module.
//
// All functions here are pure - they read and write a single in-module store
// (`store`) so a draw performed in mock mode persists for the lifetime of the
// browser tab.

const FIRST_NAMES = [
  'Alex', 'Bailey', 'Casey', 'Dana', 'Evan', 'Frances', 'Gabriel', 'Hayden',
  'Iris', 'Jordan', 'Kelly', 'Logan', 'Morgan', 'Noah', 'Olivia', 'Parker',
  'Quinn', 'Riley', 'Sam', 'Taylor', 'Uma', 'Vera', 'Wyatt', 'Xander',
  'Yasmin', 'Zachary', 'Avery', 'Blake', 'Cameron', 'Drew', 'Eden', 'Finley',
  'Gray', 'Harper', 'Indiana', 'Jamie', 'Kai', 'Lane', 'Micah', 'Nico',
  'Oakley', 'Phoenix', 'River', 'Skyler', 'Tatum', 'Umberto', 'Vale', 'Winter',
  'Xochi', 'Yael'
]

const DEPARTMENTS = ['Engineering', 'Manufacturing', 'Quality', 'Sales', 'HR', 'Finance']

// Status enum values match the backend's ActivityStatus.
const STATUS_DISABLED = 0
const STATUS_UPCOMING = 1
const STATUS_ACTIVE = 2
const STATUS_ENDED = 3

// Build the initial store. Called lazily on first read so the dates are
// relative to "now" when the app actually loads, not when the JS file parsed.
function buildStore() {
  const now = new Date()
  const offset = (days, hours = 0) => {
    const d = new Date(now)
    d.setDate(d.getDate() + days)
    d.setHours(d.getHours() + hours)
    return d
  }

  const employees = FIRST_NAMES.map((name, i) => ({
    interID: i + 1,
    cardNumber: `E${(1001 + i).toString().padStart(5, '0')}`,
    name,
    department: DEPARTMENTS[i % DEPARTMENTS.length],
    disabled: false
  }))

  const celebrations = [
    {
      interID: 1,
      code: 'CEL2026',
      name: '2026 New Year Celebration',
      startTime: offset(-1).toISOString(),
      endTime: offset(7).toISOString(),
      disabled: false
    },
    {
      interID: 2,
      code: 'MID2026',
      name: 'Mid-Year Celebration 2026',
      startTime: offset(60).toISOString(),
      endTime: offset(67).toISOString(),
      disabled: false
    },
    {
      interID: 3,
      code: 'CEL2025',
      name: '2025 Spring Festival',
      startTime: offset(-90).toISOString(),
      endTime: offset(-83).toISOString(),
      disabled: false
    }
  ]

  const prizeMaster = [
    { code: 'P1', name: 'Grand Prize', description: 'Tropical vacation package for two, including flights and accommodation.', imagePath: 'https://picsum.photos/seed/lottery-grand/600/400', quantity: 1, numberOfRound: 1, disabled: false },
    { code: 'P2', name: 'First Prize', description: 'Latest-generation laptop computer.', imagePath: 'https://picsum.photos/seed/lottery-laptop/600/400', quantity: 2, numberOfRound: 1, disabled: false },
    { code: 'P3', name: 'Second Prize', description: 'Premium wireless headphones.', imagePath: 'https://picsum.photos/seed/lottery-headphones/600/400', quantity: 5, numberOfRound: 1, disabled: false },
    { code: 'P4', name: 'Third Prize', description: 'Smart fitness watch.', imagePath: 'https://picsum.photos/seed/lottery-watch/600/400', quantity: 8, numberOfRound: 2, disabled: false },
    { code: 'P5', name: 'Participation Prize', description: 'Branded merchandise gift box.', imagePath: 'https://picsum.photos/seed/lottery-giftbox/600/400', quantity: 20, numberOfRound: 5, disabled: false }
  ]

  // Junction with priority. Active celebration gets all 5 prizes; the ended
  // one gets two so the winners page has historical data.
  const celebrationPrizes = [
    { celebrationCode: 'CEL2026', prizeCode: 'P1', priority: 100 },
    { celebrationCode: 'CEL2026', prizeCode: 'P2', priority: 80 },
    { celebrationCode: 'CEL2026', prizeCode: 'P3', priority: 60 },
    { celebrationCode: 'CEL2026', prizeCode: 'P4', priority: 40 },
    { celebrationCode: 'CEL2026', prizeCode: 'P5', priority: 20 },
    { celebrationCode: 'CEL2025', prizeCode: 'P3', priority: 60 },
    { celebrationCode: 'CEL2025', prizeCode: 'P5', priority: 20 }
  ]

  // Pre-existing winners. Same set the backend seeds.
  const seedWin = offset(0, -2).toISOString()
  const oldWin = offset(-85).toISOString()
  const winners = [
    { interID: 1, employeeCardNumber: employees[0].cardNumber, employeeName: employees[0].name, department: employees[0].department, celebrationCode: 'CEL2026', celebrationName: celebrations[0].name, prizeCode: 'P5', prizeName: 'P5 - Participation Prize', quantity: 1, winTime: seedWin, absentFlag: false, createdTime: seedWin },
    { interID: 2, employeeCardNumber: employees[1].cardNumber, employeeName: employees[1].name, department: employees[1].department, celebrationCode: 'CEL2026', celebrationName: celebrations[0].name, prizeCode: 'P5', prizeName: 'P5 - Participation Prize', quantity: 1, winTime: seedWin, absentFlag: false, createdTime: seedWin },
    { interID: 3, employeeCardNumber: employees[2].cardNumber, employeeName: employees[2].name, department: employees[2].department, celebrationCode: 'CEL2025', celebrationName: celebrations[2].name, prizeCode: 'P3', prizeName: 'P3 - Second Prize', quantity: 1, winTime: oldWin, absentFlag: false, createdTime: oldWin },
    { interID: 4, employeeCardNumber: employees[3].cardNumber, employeeName: employees[3].name, department: employees[3].department, celebrationCode: 'CEL2025', celebrationName: celebrations[2].name, prizeCode: 'P5', prizeName: 'P5 - Participation Prize', quantity: 1, winTime: oldWin, absentFlag: true, createdTime: oldWin }
  ]

  return { celebrations, employees, prizeMaster, celebrationPrizes, winners, nextWinnerId: 5 }
}

let store = null
function getStore() {
  if (!store) store = buildStore()
  return store
}

// ---- Helpers ----

function statusOf(c) {
  if (c.disabled) return STATUS_DISABLED
  const now = Date.now()
  const start = new Date(c.startTime).getTime()
  const end = new Date(c.endTime).getTime()
  if (now < start) return STATUS_UPCOMING
  if (now > end) return STATUS_ENDED
  return STATUS_ACTIVE
}

function decorateActivity(c) {
  const s = getStore()
  return {
    interID: c.interID,
    code: c.code,
    name: c.name,
    startTime: c.startTime,
    endTime: c.endTime,
    disabled: c.disabled,
    status: statusOf(c),
    prizeCount: s.celebrationPrizes.filter((cp) => cp.celebrationCode === c.code).length,
    winnerCount: s.winners.filter((w) => w.celebrationCode === c.code && !w.absentFlag).length
  }
}

function buildPrizeDto(celebrationCode, prizeCode) {
  const s = getStore()
  const cp = s.celebrationPrizes.find(
    (x) => x.celebrationCode === celebrationCode && x.prizeCode === prizeCode
  )
  if (!cp) return null
  const p = s.prizeMaster.find((x) => x.code === prizeCode)
  if (!p || p.disabled) return null
  const c = s.celebrations.find((x) => x.code === celebrationCode)
  if (!c || c.disabled) return null

  const winsForPrize = s.winners.filter(
    (w) => w.celebrationCode === celebrationCode && w.prizeCode === prizeCode
  )
  const winnedQuantity = winsForPrize.filter((w) => !w.absentFlag).length
  const absentQty = winsForPrize.filter((w) => w.absentFlag).length

  return {
    celebrationCode: c.code,
    celebrationName: c.name,
    code: p.code,
    name: p.name,
    description: p.description,
    imagePath: p.imagePath,
    quantity: p.quantity,
    numberOfRound: p.numberOfRound,
    winnedQuantity,
    absentQty,
    priority: cp.priority,
    remainQty: p.quantity - winnedQuantity,
    status: winnedQuantity >= p.quantity ? 1 : 0
  }
}

// Fisher-Yates pick (mirrors backend RandomSelection.PickRandom).
function pickRandom(source, count) {
  const arr = [...source]
  if (count >= arr.length) count = arr.length
  for (let i = 0; i < count; i++) {
    const j = i + Math.floor(Math.random() * (arr.length - i))
    ;[arr[i], arr[j]] = [arr[j], arr[i]]
  }
  return arr.slice(0, count)
}

// ---- Public API (mirrors the axios-backed wrappers in src/api) ----

export const mockApi = {
  getAllActivities() {
    const s = getStore()
    return s.celebrations
      .slice()
      .sort((a, b) => new Date(b.startTime) - new Date(a.startTime))
      .map(decorateActivity)
  },

  getActiveActivity() {
    const s = getStore()
    const now = Date.now()
    const candidates = s.celebrations.filter(
      (c) => !c.disabled
        && new Date(c.startTime).getTime() <= now
        && new Date(c.endTime).getTime() >= now
    )
    if (candidates.length === 0) return null

    // Same ranking as the backend - by D1 (minutes since start), then midpoint, then D2.
    const ranked = candidates
      .map((c) => {
        const d1 = Math.floor((now - new Date(c.startTime).getTime()) / 60000)
        const d2 = Math.floor((new Date(c.endTime).getTime() - now) / 60000)
        return { c, d1, d2 }
      })
      .sort((a, b) =>
        a.d1 - b.d1
        || ((a.d1 + a.d2) / 2) - ((b.d1 + b.d2) / 2)
        || a.d2 - b.d2
      )
    return decorateActivity(ranked[0].c)
  },

  getActivityByCode(code) {
    const s = getStore()
    const c = s.celebrations.find((x) => x.code === code)
    return c ? decorateActivity(c) : null
  },

  getPrizesByCelebration(celebrationCode, onlyUnfinished = false) {
    const s = getStore()
    return s.celebrationPrizes
      .filter((cp) => cp.celebrationCode === celebrationCode)
      .map((cp) => buildPrizeDto(celebrationCode, cp.prizeCode))
      .filter((p) => p && (!onlyUnfinished || p.remainQty > 0))
      .sort((a, b) => b.priority - a.priority || a.code.localeCompare(b.code))
  },

  getEligibleEmployees(celebrationCode) {
    const s = getStore()
    const winnerCardNumbers = new Set(
      s.winners
        .filter((w) => w.celebrationCode === celebrationCode)
        .map((w) => w.employeeCardNumber)
    )
    return s.employees
      .filter((e) => !e.disabled && !winnerCardNumbers.has(e.cardNumber))
      .sort((a, b) => a.cardNumber.localeCompare(b.cardNumber))
  },

  draw(celebrationCode, prizeCode) {
    const s = getStore()
    const c = s.celebrations.find((x) => x.code === celebrationCode)
    if (!c) throw makeError('OPS--LOT-DataNotExist', `Celebration '${celebrationCode}' does not exist.`)
    if (statusOf(c) !== STATUS_ACTIVE) {
      throw makeError('OPS--LOT-CelebrationNotActive', `Celebration '${celebrationCode}' is not currently active.`)
    }

    const prizeDto = buildPrizeDto(celebrationCode, prizeCode)
    if (!prizeDto) {
      throw makeError('OPS--LOT-DataNotExist', `Prize '${prizeCode}' is not configured for celebration '${celebrationCode}'.`)
    }
    if (prizeDto.remainQty <= 0) {
      throw makeError('OPS--LOT-PrizeAlreadyDone', `Prize '${prizeCode}' has already been fully drawn.`)
    }

    const eligible = mockApi.getEligibleEmployees(celebrationCode)
    if (eligible.length === 0) {
      throw makeError('OPS--LOT-NoEligibleEmployees', 'No eligible employees remain for this celebration.')
    }

    const roundSize = Math.min(
      prizeDto.numberOfRound,
      prizeDto.remainQty,
      eligible.length
    )

    const picked = pickRandom(eligible, roundSize)
    const now = new Date().toISOString()
    const winners = picked.map((emp) => {
      const id = s.nextWinnerId++
      const row = {
        interID: id,
        employeeCardNumber: emp.cardNumber,
        employeeName: emp.name,
        department: emp.department,
        celebrationCode,
        celebrationName: c.name,
        prizeCode,
        prizeName: `${prizeCode} - ${prizeDto.name}`,
        quantity: 1,
        winTime: now,
        absentFlag: false,
        createdTime: now
      }
      s.winners.push(row)
      return row
    })

    // Round number = floor(totalRowsForPrize / NumberOfRound) + 1 (matches backend).
    const totalRowsForPrize = s.winners.filter(
      (w) => w.celebrationCode === celebrationCode && w.prizeCode === prizeCode
    ).length

    return {
      celebrationCode,
      prizeCode,
      prizeName: `${prizeCode} - ${prizeDto.name}`,
      roundNumber: Math.floor(totalRowsForPrize / Math.max(prizeDto.numberOfRound, 1)) + 1,
      winnersPicked: winners.length,
      remainQty: prizeDto.remainQty - winners.length,
      winners
    }
  },

  queryWinners({ celebrationCode, prizeCode, beginTime, endTime } = {}) {
    const s = getStore()
    const begin = beginTime ? new Date(beginTime).getTime() : Date.now() - 7 * 24 * 60 * 60 * 1000
    const end = endTime ? new Date(endTime).getTime() : Date.now() + 24 * 60 * 60 * 1000

    return s.winners
      .filter((w) => {
        const t = new Date(w.createdTime).getTime()
        if (t < begin || t > end) return false
        if (celebrationCode && w.celebrationCode !== celebrationCode) return false
        if (prizeCode && w.prizeCode !== prizeCode) return false
        return true
      })
      .slice()
      .sort((a, b) => new Date(b.winTime) - new Date(a.winTime) || b.interID - a.interID)
  },

  updateAbsent({ celebrationCode, employeeCardNumber, absentFlag }) {
    const s = getStore()
    const row = s.winners.find(
      (w) => w.celebrationCode === celebrationCode && w.employeeCardNumber === employeeCardNumber
    )
    if (!row) return false
    row.absentFlag = absentFlag
    return true
  },

  deleteWinner(celebrationCode, employeeCardNumber) {
    const s = getStore()
    const idx = s.winners.findIndex(
      (w) => w.celebrationCode === celebrationCode && w.employeeCardNumber === employeeCardNumber
    )
    if (idx < 0) return false
    s.winners.splice(idx, 1)
    return true
  }
}

function makeError(code, message) {
  const err = new Error(message)
  err.code = code
  err.envelope = { success: false, code, message, data: null }
  return err
}

import http, { withMockFallback } from './http'
import { mockApi } from './mockData'

// Wrapper around /api/Prizes.
export const prizesApi = {
  getByCelebration(celebrationCode) {
    return withMockFallback(
      () => http.get(`/Prizes/celebration/${encodeURIComponent(celebrationCode)}`),
      () => mockApi.getPrizesByCelebration(celebrationCode, false)
    )
  },

  getUnfinished(celebrationCode) {
    return withMockFallback(
      () => http.get(`/Prizes/celebration/${encodeURIComponent(celebrationCode)}/unfinished`),
      () => mockApi.getPrizesByCelebration(celebrationCode, true)
    )
  },

  getOne(celebrationCode, prizeCode) {
    return withMockFallback(
      () => http.get(
        `/Prizes/celebration/${encodeURIComponent(celebrationCode)}/prize/${encodeURIComponent(prizeCode)}`
      ),
      () => {
        const all = mockApi.getPrizesByCelebration(celebrationCode, false)
        return all.find((p) => p.code === prizeCode) || null
      }
    )
  }
}

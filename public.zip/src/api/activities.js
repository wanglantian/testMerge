import http, { withMockFallback } from './http'
import { mockApi } from './mockData'

// Wrapper around /api/Activities. Each call attempts the real backend first
// and falls back to the in-browser mock store on network failure.
export const activitiesApi = {
  getAll() {
    return withMockFallback(
      () => http.get('/Activities'),
      () => mockApi.getAllActivities()
    )
  },

  getActive() {
    return withMockFallback(
      () => http.get('/Activities/active'),
      () => mockApi.getActiveActivity()
    )
  },

  getByCode(code) {
    return withMockFallback(
      () => http.get(`/Activities/${encodeURIComponent(code)}`),
      () => mockApi.getActivityByCode(code)
    )
  }
}

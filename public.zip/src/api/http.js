import axios from 'axios'
import notify from 'devextreme/ui/notify'

// Axios instance for all API calls. Uses a relative baseURL so Vite's dev proxy
// forwards /api to the .NET backend. In production the same path will be served
// by the backend host or a reverse proxy.
const http = axios.create({
  baseURL: '/api',
  timeout: 8000,                    // Short enough that the mock fallback kicks in fast.
  headers: {
    'Content-Type': 'application/json'
  }
})

// -------- Request interceptor --------
http.interceptors.request.use(
  (config) => {
    config.headers['X-Request-Time'] = new Date().toISOString()
    return config
  },
  (error) => Promise.reject(error)
)

// -------- Response interceptor --------
// The backend always returns ApiResponse<T> envelopes. We unwrap the envelope
// here so call sites can `await api.fetch()` and receive `data` directly.
http.interceptors.response.use(
  (response) => {
    const envelope = response.data

    if (envelope && typeof envelope === 'object' && 'success' in envelope) {
      if (envelope.success) {
        return envelope.data
      }

      // Business-rule failure. Show a warning, not a destructive error.
      notify(
        {
          message: envelope.message || 'Request failed',
          type: 'warning',
          displayTime: 3500,
          position: { my: 'top center', at: 'top center', offset: '0 24' }
        },
        'warning',
        3500
      )

      const err = new Error(envelope.message || 'Request failed')
      err.code = envelope.code
      err.envelope = envelope
      err.isBusinessFailure = true
      return Promise.reject(err)
    }

    return response.data
  },
  (error) => {
    // Mark transport-level errors so callers can decide to swallow them and
    // fall back to the mock store. We DON'T toast here - the caller toasts
    // only if no mock fallback is being used.
    error.isTransportFailure = true
    return Promise.reject(error)
  }
)

/**
 * Whether the most recent transport call failed. Used by the api/* modules to
 * decide whether to keep trying the backend or stick with the mock store.
 *
 * Reset on every page navigation (the user might have started the backend in
 * between), but sticky within a single page so we don't spam the network.
 */
let backendDown = false

export function markBackendDown() { backendDown = true }
export function isBackendDown() { return backendDown }
export function resetBackendStatus() { backendDown = false }

/**
 * Toast helper for use by mock-fallback wrappers that want to surface a
 * "demo mode" notice the first time the backend turns out to be unreachable.
 */
let demoNoticeShown = false
export function showDemoModeNoticeOnce() {
  if (demoNoticeShown) return
  demoNoticeShown = true
  notify(
    {
      message: 'Backend not reachable - showing mock data so you can browse the UI.',
      type: 'info',
      displayTime: 5000,
      position: { my: 'top center', at: 'top center', offset: '0 24' }
    },
    'info',
    5000
  )
}

/**
 * Run a real-API call with automatic mock fallback on network failure.
 * @param {() => Promise<T>} apiCall   The axios call.
 * @param {() => T}          mockCall  The synchronous mock equivalent.
 */
export async function withMockFallback(apiCall, mockCall) {
  const mode = (import.meta.env.VITE_DATA_MODE || 'auto').toLowerCase()

  if (mode === 'mock') {
    return mockCall()
  }

  if (mode === 'backend') {
    return await apiCall()
  }

  // Auto: try backend first. If it's already known to be down, skip the
  // network call and go straight to the mock store.
  if (backendDown) {
    return mockCall()
  }

  try {
    return await apiCall()
  } catch (err) {
    if (err?.isTransportFailure) {
      markBackendDown()
      showDemoModeNoticeOnce()
      return mockCall()
    }
    // Business failures bubble up as-is (the response interceptor already
    // toasted them).
    throw err
  }
}

export default http

import http, { withMockFallback } from './http'
import { mockApi } from './mockData'

// Wrapper around /api/Lottery.
export const lotteryApi = {
  getEligible(celebrationCode) {
    return withMockFallback(
      () => http.get(`/Lottery/eligible/${encodeURIComponent(celebrationCode)}`),
      () => mockApi.getEligibleEmployees(celebrationCode)
    )
  },

  draw(celebrationCode, prizeCode) {
    return withMockFallback(
      () => http.post('/Lottery/draw', { celebrationCode, prizeCode }),
      () => mockApi.draw(celebrationCode, prizeCode)
    )
  }
}
